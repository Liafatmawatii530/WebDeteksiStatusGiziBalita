from flask import Flask, render_template, request
import pickle
import pandas as pd

app = Flask(__name__)

# Load model and scaler
with open('stunting_risk_model.sav', 'rb') as model_file:
    classifier = pickle.load(model_file)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/pengenalan')
def pengenalan():
    return render_template('pengenalan.html')

@app.route('/pencegahan')
def pencegahan():
    return render_template('pencegahan.html')

@app.route('/gejala')
def gejala():
    return render_template('gejala.html')

@app.route('/deteksi', methods=['GET', 'POST'])
def deteksi():
    if request.method == 'POST':
        try:
            # Get data from form and convert to float
            Umur = float(request.form['Umur (bulan)'])
            gender = float(request.form['Jenis Kelamin'])
            tb = float(request.form['Tinggi Badan (cm)'])

            # Prepare data for prediction
            input_data = pd.DataFrame({
                'Umur (bulan)': [Umur], 
                'Jenis Kelamin': [gender], 
                'Tinggi Badan (cm)': [tb]
            })

            # Predict
            prediction = classifier.predict(input_data)

            # Interpreting the prediction result
            if prediction[0] == 0:
                diagnosis = 'Status Gizi : Severely Stunted'
            elif prediction[0] == 1:
                diagnosis = 'Status Gizi : Stunted'
            elif prediction[0] == 2:
                diagnosis = 'Status Gizi : Normal'
            else:
                diagnosis = 'Status Gizi : Tinggi'

            return render_template('deteksi.html', result=diagnosis)
        except ValueError:
            return render_template('deteksi.html', result='Harap masukkan semua nilai numerik dengan benar.')

    return render_template('deteksi.html', result='')

if __name__ == '__main__':
    app.run(debug=True)
